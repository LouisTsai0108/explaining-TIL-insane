var x = 0; 

function increment() {
  document.getElementByClass("custom-select").innerHTML = ++x;
}

